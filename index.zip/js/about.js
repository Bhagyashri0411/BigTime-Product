// alert('jhjj')
$(document).ready(function () {
    $("#startaproject").load("./Templates/Modals/Contact.html");
    $("#inquiry").load("./Templates/Modals/Inquiry.html");
    $("#modelogin").load("./Templates/Modals/Loginmodel.html");
    $("#header").load("./Templates/Header.html");
    $("#about").load("./Maincode/About.html");
    $("#footer").load("./Templates/footer.html");
})