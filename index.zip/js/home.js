// alert('jhjj')
$(document).ready(function () {
    $("#showme").load("./Dashboard/Dashboard.php");
    $("#header").load("./Templates/Header.html");
    $("#inquiry").load("./Templates/Modals/Inquiry.html");
    $("#modelogin").load("./Templates/Modals/Loginmodel.html");
    $("#startaproject").load("./Templates/Modals/Contact.html");
    $("#Page_contant").load("./Maincode/Home.html");
    $("#secondiv").load("./Maincode/secondiv.html");
    $("#client").load("./Maincode/Client.html");
    $("#Footer").load("./Maincode/Footer.html");
    
})