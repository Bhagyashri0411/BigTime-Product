<!DOCTYPE html>
<html lang="en">

<head>
   <?php
    include './jsfileconnection/head.html';
    ?>
</head>

<body>

   <!-- header section starts  -->
   <?php
    include './Components/header.html';
    ?>
   <!-- header section ends -->

   <!-- home section starts  -->

<?php
 include './Pages/home.php'; 
include './jsfileconnection/js.html';
include './Components/footer.html'
?>

</body>

</html>