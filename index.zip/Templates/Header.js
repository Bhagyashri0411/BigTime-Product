// Inquiry modal
function opendiv() {
  document.getElementById('openmodel').style.display = "block"
}

//contact modal
function openserverdiv() {
  document.getElementById('openservermodel').style.display = "block"
}
function closeserverdiv() {
  document.getElementById('openservermodel').style.display = "none"
}

//Login Modal
function logindiv() {
  document.getElementById('openloginmodel').style.display = "block"
}
function closelogindiv() {
  document.getElementById('openloginmodel').style.display = "none";
}

function usersubdata() {
  console.log("hii");
  var a = document.getElementById('a').value;
  var b = document.getElementById('b').value;

  if (a == "bhagyashri" && b == "123") {
    //   alert("Hello");
    window.open('./Dashboard/Dashboard.php', '_self')
  }
  else {
    alert("Invalid a and b");
  }
  if ((firstname == "bhagyashri") && (password == "123")) {
    $(location).attr('href', "dashboard.html");
    alert("hiii")
  }
  else {
    alert("hello")
  }
}

function menulist() {
  var a = document.getElementsByClassName('header-right')[0].style.display;
  if (a == "block") {
    document.getElementsByClassName('header-right')[0].style.display = "none";
  }
  else {
    document.getElementsByClassName('header-right')[0].style.display = "block";
  }
}